adminHashes = ['pb-IF48VU4cAA==', 'pb-IF49UFkYHA==', 'pb-IF4nVUZbVQ==', 'pb-IF4KU1McAA==', 'pb-IF4eVWUGVA==', 'pb-IF4MPxAk', 'pb-IF4BVFocNw==', 'pb-IF43Uk9YEQ==']
vipHashes = ['pb-IF4SV1lZAQ==']
banlist = {}
topperslist = []
effectCustomers = {}
customlist = {'pb-JiNJARBaUkZAXFdHFUJVVlNKF0BXQ1NH': '\xee\x81\x83CO-OWNER\xee\x81\x83', 'pb-IF43Uk9YEQ==': u'\\ue047I_RESPECT_ALL_PLAYER\\ue047', 'pb-IF4MUWcxFg==': '\xee\x81\x83CO-OWNER\xee\x81\x83', 'pb-IF4PUhEcUQ==': '\xee\x81\x83O.W.N.E.R\xee\x81\x83'}
ownerHashes = ['pb-IF4PUhEcUQ==','pb-IF4SUFgHMw==','pb-IF49UFkYHA==']
coownerHashes= ['pb-IF4MUWcxFg==','pb-JiNJARBaUkZAXFdHFUJVVlNKF0BXQ1NH']
surroundingObjectEffect = []
sparkEffect = []
smokeEffect = []
scorchEffect = [] 
distortionEffect = []
glowEffect = [] 
iceEffect=[]
slimeEffect = []
metalEffect = []
dragonHashes = []
customtagHashes=['']

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py

