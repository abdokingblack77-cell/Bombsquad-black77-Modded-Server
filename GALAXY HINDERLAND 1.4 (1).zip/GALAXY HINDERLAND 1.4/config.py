# place any of your own overrides here.
# see bombsquad_server for details on what you can override
# examples (uncomment to use):
# config['partyName'] = 'My Awesome Party'
# config['sessionType'] = 'teams'
# config['maxPartySize'] = 6
# config['port'] = 43209
# config['playlistCode'] = 1242
